#include<iostream>
#include<string.h>
using namespace std;

class A
{
    protected:
    int id;
    char name[20];
    char role[30];
    int salary;
    char exp[10];
    char cmp_name[40];
    char add[100];
    char email[50];
    int contact;
    public:
    void input(int id,char name[],char role[])
    {
        cout<<"enter your id:";
        cin>>id;
        cout<<"enter your name:";
        gets(name);
        cout<<"enter your role:";
        gets(role);
    }
};
class B:public A
{
    public:
    void input(int salary,char exp[])
    {
        cout<<"enter your salary:";
        cin>>salary;
        cout<<"enter your experience:";
        gets(exp);
    }

};
class C:public A
{
    public:
    void input(char cmp_name,char add)
    {
        cout<<"enter your company name:";
        gets(cmp_name);
        cout<<"enter your address:";
        gets(add);
    }
    void output()
    {
        cout<<"NAME:"<<name<<endl;
        cout<<"ROLE:"<<role<<endl;
        cout<<"SALARY:"<<salary<<endl;
    }

};

class D:public A
{
    public:
    cout<<"enter your email:";
    gets(email);
    cout<<"enter your contact:";
    cin>>

};
int main()
{

}
